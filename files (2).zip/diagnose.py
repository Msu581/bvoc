#!/usr/bin/env python3
"""
diagnose.py — show exactly what the audit tool can and cannot read from one PDF.

Run this on any transcript that comes back blank or wrong:

    python diagnose.py "C:\\transcripts\\some_student.pdf"

It prints, page by page: whether there is any selectable text, the semester headings it
found, the course rows it recognised, and the grand totals. Send the output (or a screenshot
of it) if the file still will not parse.
"""

import sys
from pathlib import Path

try:
    import pdfplumber
except ImportError:
    sys.exit("pdfplumber is not installed. Run: pip install pdfplumber openpyxl")

from transcript_audit import (
    CREDIT_TRIPLE_RE, COURSE_CODE_RE, _lines, _semester_number_at,
    _grab_header_fields, parse_pdf, validate,
)
from decimal import Decimal


def main() -> int:
    if len(sys.argv) < 2:
        path = input("Path of the PDF to inspect: ").strip().strip('"').strip("'")
    else:
        path = sys.argv[1].strip().strip('"').strip("'")

    p = Path(path).expanduser()
    if not p.is_file():
        return print(f"No file at: {p}") or 2

    print("=" * 74)
    print(f"  Diagnosing: {p.name}")
    print(f"  Size: {p.stat().st_size:,} bytes")
    print("=" * 74)

    with pdfplumber.open(str(p)) as pdf:
        print(f"\nPages: {len(pdf.pages)}")
        total_chars = 0
        for i, page in enumerate(pdf.pages, 1):
            words = page.extract_words()
            text = page.extract_text() or ""
            total_chars += len(text.strip())
            n_images = len(page.images)
            print(f"\n--- Page {i} — {page.width:.0f} x {page.height:.0f} pt, "
                  f"{len(words)} words, {len(text.strip())} chars of text, "
                  f"{n_images} image(s)")

            if not text.strip():
                print("    !! No selectable text on this page.")
                if n_images:
                    print("       It is a scanned image. OCR is required, for example:")
                    print("       ocrmypdf input.pdf output.pdf")
                continue

            heads = []
            for _t, ws in _lines(words):
                toks = [w["text"] for w in ws]
                for j, w in enumerate(ws):
                    if w["text"].strip(" -:.").upper() == "SEMESTER":
                        heads.append((_semester_number_at(toks, j), round(w["x0"]),
                                      round(w["top"]), " ".join(toks[max(0, j - 2):j + 3])))
            if heads:
                print("    Semester headings found:")
                for num, x, y, context in heads:
                    tag = f"semester {num}" if num else "NUMBER NOT RECOGNISED"
                    print(f"      x={x:<4} y={y:<4} -> {tag:<24} | text: {context!r}")
            else:
                print("    !! No semester headings found on this page.")
                if "SEMESTER" in text.upper():
                    print("       The word SEMESTER is present but not in a recognised form.")

            triples = [w for w in words if CREDIT_TRIPLE_RE.match(w["text"])]
            codes = [w for w in words if COURSE_CODE_RE.match(w["text"])]
            print(f"    Credit triples (e.g. 3-0-0) found: {len(triples)}")
            print(f"    Course-code-like tokens found:     {len(codes)}")
            if not triples and codes:
                print("       !! Course codes but no T-P-PR credits — the credit column is")
                print("          formatted differently than expected.")

        if total_chars == 0:
            print("\n" + "=" * 74)
            print("  VERDICT: this PDF has no text layer at all. It is a picture of a")
            print("  transcript, not a transcript. No tool can read the marks from it")
            print("  without OCR. Get the original text PDF from the exam system, or run:")
            print("      pip install ocrmypdf  &&  ocrmypdf in.pdf out.pdf")
            print("=" * 74)
            return 1

    print("\n" + "=" * 74)
    print("  Header fields read")
    print("=" * 74)
    with pdfplumber.open(str(p)) as pdf:
        full = "\n".join((pg.extract_text() or "") for pg in pdf.pages)
    hdr = _grab_header_fields(full)
    if hdr:
        for k, v in hdr.items():
            print(f"  {k:<22}: {v!r}")
    else:
        print("  !! No 'Label : value' header fields recognised.")

    print("\n" + "=" * 74)
    print("  Parsed result")
    print("=" * 74)
    tr = parse_pdf(str(p))
    for pe in tr.parse_errors:
        print(f"  PARSE PROBLEM: {pe}")
    if not tr.semesters:
        print("  No semesters parsed.")
    for num in sorted(tr.semesters):
        sem = tr.semesters[num]
        print(f"\n  Semester {num} — printed CREDITS: {sem.credits_printed}, "
              f"printed SGPA: {sem.sgpa_printed}, course rows: {len(sem.courses)}")
        for c in sem.courses:
            print(f"    {c.code or '(no code)':<10} {c.credit_triple:<8} "
                  f"marks={c.marks_raw:<4} grade={c.grade_printed:<3} "
                  f"credit={c.credit:<3} {c.name[:40]}")

    print("\n  Grand totals read from the PDF:")
    for label, val in [("MAX MARKS", tr.max_marks_printed),
                       ("OBTAINED MARKS", tr.obtained_printed),
                       ("PERCENTAGE", tr.percentage_printed),
                       ("TOTAL CREDITS", tr.total_credits_printed),
                       ("CGPA", tr.cgpa_printed)]:
        print(f"    {label:<16}: {val if val is not None else '!! NOT FOUND'}")

    res = validate(tr, Decimal("0.0"))
    print("\n" + "=" * 74)
    print(f"  Verdict: {res.status} — {res.n_errors} error(s), {res.n_warnings} warning(s)")
    print("=" * 74)
    for i in res.issues:
        print(f"  {i.severity:<8} {i.code:<6} {i.location:<22} {i.message}")
        if i.printed or i.computed:
            print(f"           printed: {i.printed!r}   correct: {i.computed!r}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
