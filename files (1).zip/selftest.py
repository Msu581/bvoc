"""Self-test: builds synthetic transcripts and asserts each check fires."""
from decimal import Decimal
from transcript_audit import Transcript, Semester, Course, validate

TOL = Decimal("0.0")


def mk(code, cred, marks, grade, t=None):
    a, b, c = (cred, 0, 0) if t is None else t
    return Course(code=code, name=code, credit_triple=f"{a}-{b}-{c}",
                  theory=a, practical=b, practice=c, marks_raw=str(marks), grade_printed=grade)


def base(cat="Regular", prog="Bachelor of Vocation"):
    tr = Transcript(file="synthetic.pdf", student="Test", category_printed=cat,
                    programme_printed=prog)
    return tr


def codes(res):
    return {i.code for i in res.issues}


# 1. A fully correct BVoc regular transcript -> no errors
tr = base()
for s in range(1, 7):
    sem = Semester(number=s, courses=[mk(f"AA{s}0{i}", 4, 85, "A") for i in range(3)],
                   credits_printed=12, sgpa_printed="8.0")
    tr.semesters[s] = sem
tr.max_marks_printed = 1800
tr.obtained_printed = 85 * 18
tr.percentage_printed = "85.0"
tr.total_credits_printed = 72
tr.cgpa_printed = "8.0"
r = validate(tr, TOL)
assert r.n_errors == 0, [i.message for i in r.issues if i.severity == "ERROR"]
print("PASS  clean transcript -> 0 errors")

# 2. Wrong category wording
tr = base(cat="Lateral Entry (2nd Year)")
for s in (3, 4, 5, 6):
    tr.semesters[s] = Semester(number=s, courses=[mk(f"BB{s}01", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
tr.max_marks_printed, tr.obtained_printed = 400, 340
tr.percentage_printed, tr.total_credits_printed, tr.cgpa_printed = "85.0", 16, "8.0"
r = validate(tr, TOL)
assert "C001" in codes(r) and r.category_key == "LATERAL_2"
print("PASS  wrong category wording -> C001, still inferred LATERAL_2")

# 3. Missing semester in the middle (3,4,6)
tr = base(cat="Lateral Entry to Second Year")
for s in (3, 4, 6):
    tr.semesters[s] = Semester(number=s, courses=[mk(f"CC{s}01", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
r = validate(tr, TOL)
assert "S010" in codes(r) and "S012" in codes(r)
print("PASS  gap 3,4,6 -> S010 missing + S012 non-consecutive")

# 4. Lateral 3rd year that wrongly includes semester 4
tr = base(cat="Lateral Entry to Third Year")
for s in (4, 5, 6):
    tr.semesters[s] = Semester(number=s, courses=[mk(f"DD{s}01", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
r = validate(tr, TOL)
assert "S011" in codes(r)
print("PASS  lateral-3rd with sem 4 -> S011 unexpected semester")

# 5. Grade wrong for the marks, and SGPA computed from the correct grade point
tr = base()
tr.semesters[1] = Semester(number=1, courses=[mk("EE101", 4, 79, "A")],  # 79 is B+, not A
                           credits_printed=4, sgpa_printed="8.0")
for s in range(2, 7):
    tr.semesters[s] = Semester(number=s, courses=[mk(f"EE{s}01", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
r = validate(tr, TOL)
assert "G001" in codes(r), codes(r)
sem1 = next(sc for sc in r.semester_checks if sc.sem == 1)
assert sem1.sgpa_rounded == "7.0" and not sem1.sgpa_ok
print("PASS  grade mismatch -> G001, SGPA recomputed as 7.0 from the true grade point")

# 6. Semester credit total disagrees with the T-P-PR sum
tr = base()
tr.semesters[1] = Semester(number=1, courses=[mk("FF101", 0, 85, "A", t=(2, 3, 0))],
                           credits_printed=6, sgpa_printed="8.0")  # real total is 5
r = validate(tr, TOL)
assert "S021" in codes(r)
s021 = next(i for i in r.issues if i.code == "S021")
assert s021.printed == "6" and s021.computed == "5"
print("PASS  credit sum 2-3-0=5 vs printed 6 -> S021")

# 7. Totals: wrong max marks, obtained, percentage, credits, CGPA
tr = base()
for s in range(1, 7):
    tr.semesters[s] = Semester(number=s, courses=[mk(f"GG{s}01", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
tr.max_marks_printed = 700     # should be 600
tr.obtained_printed = 500      # should be 510
tr.percentage_printed = "71.4"  # should be 85.0
tr.total_credits_printed = 20  # should be 24
tr.cgpa_printed = "9.0"        # should be 8.0
r = validate(tr, TOL)
assert {"T050", "T051", "T052", "T053", "T054"} <= codes(r), codes(r)
print("PASS  all five grand totals wrong -> T050/T051/T052/T053/T054")

# 8. Duplicate course code across semesters
tr = base()
for s in range(1, 7):
    tr.semesters[s] = Semester(number=s, courses=[mk("HH101", 4, 85, "A")],
                               credits_printed=4, sgpa_printed="8.0")
r = validate(tr, TOL)
assert "R002" in codes(r)
print("PASS  repeated course code -> R002")

# 9. Absent + fail warnings
tr = base()
tr.semesters[1] = Semester(number=1,
                           courses=[mk("II101", 4, "AB", "AB"), mk("II102", 4, 31, "F")],
                           credits_printed=8, sgpa_printed="0.0")
r = validate(tr, TOL)
assert "G004" in codes(r) and "G003" in codes(r)
print("PASS  AB and sub-40 marks -> G004 / G003 warnings")

# 10. Rounding boundary: 8.545454... must round to 8.5, not 8.6
tr = base()
tr.semesters[1] = Semester(
    number=1,
    courses=[mk("JJ101", 2, 81, "A"), mk("JJ102", 2, 88, "A"), mk("JJ103", 4, 94, "A+"),
             mk("JJ104", 3, 85, "A"), mk("JJ105", 5, 95, "A+"), mk("JJ106", 3, 83, "A"),
             mk("JJ107", 3, 95, "A+")],
    credits_printed=22, sgpa_printed="8.6")
r = validate(tr, TOL)
sc = r.semester_checks[0]
assert sc.weighted_sum == 188 and sc.sgpa_rounded == "8.5" and not sc.sgpa_ok
print("PASS  188/22 = 8.545455 -> 8.5 (printed 8.6 flagged)")

print("\nAll self-tests passed.")
