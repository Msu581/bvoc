# Transcript Audit Tool

Strict verifier for Medhavi Skills University academic transcripts. Reads the PDFs, recomputes
every published figure from the course rows, and writes a multi-sheet Excel audit report.

## Install

```bash
pip install pdfplumber openpyxl
```

## Run it (simple way)

Run with no arguments and it asks you for both paths:

```bash
python transcript_audit.py
```

```
Step 1 of 2 — where are the transcript PDFs?
  PDF folder: D:\transcripts\2025
  -> Found 412 PDF file(s).

Step 2 of 2 — where should the Excel report be saved?
  Press Enter to accept: D:\transcripts\2025\transcript_audit_20250917_1432.xlsx
  Save report as: D:\reports\batch1.xlsx
```

For the PDF folder you can paste a path, drag the folder into the window, give a single `.pdf`,
or press Enter to use the current folder. Sub-folders are searched too. A wrong path just asks
again rather than crashing.

For the save location you can give a full path, a folder (the file gets a timestamped name
inside it), or just a file name (saved beside the PDFs). The `.xlsx` extension is added if you
leave it off, missing folders are created, and you are asked before overwriting an existing
file. If the report is open in Excel when it tries to save, it says so and lets you pick
another name instead of losing the run.

Quotes around a pasted path, `~`, and environment variables are all handled.

## Run it (command line, for scripts)

```bash
python transcript_audit.py ./transcripts -o audit_report.xlsx
python transcript_audit.py ./transcripts -o audit_report.xlsx --workers 8   # faster on 500 files
python transcript_audit.py a.pdf b.pdf -o out.xlsx --json raw.json
```

Giving any path argument skips the prompts entirely. `--tol 0.05` loosens the SGPA/CGPA/
percentage comparison; the default is exact match. Exit code is 1 if any error was found,
0 if clean, 2 if no PDFs were found, so it can be used in a script.

## How the parser works

The two semester blocks sit side by side, so plain text extraction interleaves them. The tool
uses word coordinates instead: it finds each `<ORDINAL> SEMESTER` header, takes the words below
it in the same half of the page, groups them into visual lines, and treats any line carrying a
`T-P-PR` credit triple as a course row. Wrapped course names are re-attached. Totals are read
from the whole document, so it does not matter whether they print on page 1 or page 2.

All arithmetic uses `decimal.Decimal`. There is no binary floating point anywhere in the
comparisons, and rounding is half-up to one decimal place (the precision the transcript prints).

## Checks

| Code | Severity | What it catches |
|---|---|---|
| P000 / P001 | ERROR | PDF unreadable, or no semester blocks found |
| C001 | ERROR | Category wording is not the exact canonical string |
| C002 | ERROR | Category not recognisable at all |
| C003 | ERROR | Programme is neither Bachelor of Vocation nor Bachelor of Design |
| S010 | ERROR | Semester missing for this category and programme |
| S011 | ERROR | Semester present that this category should not have |
| S012 | ERROR | Semesters not consecutive (e.g. 3, 4, 6) |
| S013 | ERROR | Semester block with no course rows |
| S020 / S021 | ERROR | Printed semester CREDITS missing, or not equal to the sum of T+P+PR |
| S030 / S031 | ERROR | Printed SGPA missing, or not equal to Sum(credit x point) / Sum(credit) |
| R001 | ERROR | Course code missing on a row |
| R002 | ERROR | Duplicate course code |
| R003 / R004 | ERROR | Marks unreadable or outside 0-100 |
| R005 | ERROR | Course credit (T+P+PR) is zero |
| G001 | ERROR | Grade letter does not match the marks under the page-2 grade scale |
| G002 | ERROR | Grade letter not in the scale |
| G003 | WARNING | Marks below the passing mark of 40 |
| G004 | WARNING | Student recorded absent (AB) |
| T050 | ERROR | MAX MARKS != number of course rows x 100 |
| T051 | ERROR | OBTAINED MARKS != sum of all course marks |
| T052 | ERROR | PERCENTAGE != obtained / max x 100 |
| T053 | ERROR | TOTAL CREDITS != sum of semester credits |
| T054 | ERROR | CGPA != Sum over all courses(credit x point) / total credits |
| T055 | WARNING | Sum of printed semester credits differs from the computed sum |
| T056 | INFO | The page-2 form Sum(Ci x Si)/Sum(Ci) gives a different CGPA purely from SGPA rounding |

One deliberate design point: SGPA and CGPA are recomputed from the grade point that the **marks**
earn, not from the printed grade letter. A wrong grade therefore cannot hide a wrong SGPA — both
are reported separately.

## Expected semesters

| | Regular | Lateral Entry to Second Year | Lateral Entry to Third Year |
|---|---|---|---|
| BVoc | 1-6 | 3-6 | 5-6 |
| BDes | 1-8 | 3-8 | 5-8 |

## Excel report

| Sheet | Contents |
|---|---|
| 1. Summary | One row per transcript: status, error and warning counts, error codes |
| 2. Totals Check | Max marks, obtained, percentage, total credits, CGPA — printed vs computed, with live difference formulas |
| 3. Semester Check | Per semester: credits and SGPA, printed vs computed vs exact unrounded value |
| 4. Course Check | Every course row: credits, marks, printed grade vs expected grade, credit x point |
| 5. Category & Sequence | Category wording, expected vs found semesters, missing and unexpected |
| 6. Errors & Warnings | Flat list of every finding with the printed value and the correct value |
| 7. Grade Scale | The scale used, for reference |
| 8. Run Info | Formulas, tolerance, counts, timestamp |

## Configuration

Everything rule-related sits in one block at the top of `transcript_audit.py`:
`GRADE_SCALE`, `CANONICAL_CATEGORIES`, `CATEGORY_PATTERNS`, `PROGRAMME_PATTERNS`,
`FIRST_SEMESTER`, `PASSING_MARK`, and the rounding precision constants.

Note: `CANONICAL_CATEGORIES` spells the first category `Regular`. If your office standard is a
different spelling, change that one string and the check follows.

## Tests

```bash
python selftest.py
```

Ten synthetic transcripts covering a clean pass, wrong category wording, a 3-4-6 semester gap,
an out-of-range semester, a grade/marks mismatch, a credit-sum mismatch, all five grand totals
wrong, a duplicate course code, absent and failing marks, and the 8.545455 rounding boundary.
