# Transcript Checker for Windows

A desktop application for checking up to 500 MSU School of Design transcript PDFs and saving a five-sheet Excel audit. This is source code for your other Windows computer. It does **not** start an upload server, use a browser, or send student documents to a cloud service.

## Install on the destination computer

1. Install **64-bit Python 3.11 or newer** from https://www.python.org/downloads/windows/ using the standard installer. Keep **Tcl/Tk and IDLE** and the **Python launcher** selected.
2. Install and activate **Microsoft Excel desktop**. Start Excel once to finish any first-run prompts. Excel Online is not a substitute for desktop automation.
3. Extract this entire folder to a location where you can write files. Keep `report_template.xlsx` and `recalculate.ps1` next to the Python files.
4. Double-click **Setup.bat**. It creates a local Python virtual environment and installs the two pinned PDF-reading dependencies. Internet is needed for this one-time dependency installation.
5. Double-click **Start.bat**. No Codex installation or path from the development computer is required.

## Use

1. Click **Add PDFs / ZIP**, **Add folder**, or paste paths one per line. Folder selection includes subfolders. The interface supports path/file selection; it does not require drag-and-drop.
2. Click **Check PDFs**. The application remains responsive while processing files. Cancel discards the partial batch rather than exporting an incomplete batch as finished.
3. Select a student to inspect the extracted credits, SGPA numerator/denominator and review issues. **Open selected source PDF** opens the original document, including PDFs inside a ZIP.
4. Click **Save Excel report...** and choose the destination folder and filename. An overwrite prompt is shown if the filename exists.
5. The application asks a private, hidden Excel instance to calculate and save the report. It never attaches to or closes your already-open Excel workbooks.

If Excel cannot be started automatically, the report is still saved, with formula caches explicitly labelled **PENDING EXCEL**. Open it in desktop Excel, use **Automatic calculation** or press **Ctrl+Alt+F9**, and save it. Do not treat pending formula results as completed checks.

## The five worksheets

| Sheet | Contents |
|---|---|
| Year of passing check | Student name, registration, category, programme, passing year versus 2025, expected and observed semester sequence, extraction and duplicate checks, overall result, source and file hash. |
| SGPA and credit check | One row per semester: printed credits, exact code totals, independent Excel totals, weighted points, exact SGPA fraction, unrounded SGPA, printed SGPA, **Excel ROUND(value,1)**, comparisons and grade checks. Subject-level evidence and formulas appear below the semester table. |
| Max marks checking | Unique course count within each semester summed across the programme, computed maximum marks, printed maximum marks, code/Excel/printed obtained marks and a semester breakdown. |
| Calculations | Code/Excel/printed total credits; exact, unrounded and rounded CGPA; obtained/maximum marks; computed and printed percentage; comparisons and overall result. |
| PDF Parser Cross-check | Every place the two independent text engines (pdfplumber, pypdf) produced different raw text for the same identity field, with both engines' text and the resolution. Character-level differences (e.g. a font ligature) are marked auto-resolved and do not affect any other sheet; anything else is marked REVIEW REQUIRED and also appears on the other sheets. |

Use horizontal scrolling for the detailed audit columns. Header rows and student identifiers are frozen. Filters apply to the main summary tables. Registrations remain text, so leading zeroes are preserved.

## Calculation rules

- Regular: semesters **1–6 for B.Voc**, **1–8 for B.Des**.
- Lateral to second year: **3–6 for B.Voc**, **3–8 for B.Des**.
- Lateral to third year: **5–6 for B.Voc**, **5–8 for B.Des**.
- The category is read from the PDF, not inferred from which semesters happen to exist. `Regular (Lateral Entry to Third Year)` is treated as lateral third-year entry. Missing, extra, repeated or out-of-order semesters cause a sequence mismatch.
- Course credits = T + P + PR. SGPA = SUM(course credits × grade points) / SUM(course credits).
- CGPA uses **all subject weighted points divided by all subject credits**, as requested. It does not average rounded semester SGPAs. Failed-subject credits stay in the denominator; F and AB contribute zero weighted points.
- Maximum marks = SUM(unique course codes **within each semester**) × 100. A code appearing in two different semesters counts in both. Duplicate rows within a semester are reported as ambiguous and require review; they are not silently deduplicated for marks/credits.
- Obtained marks = all subject marks summed across included semesters. AB marks contribute zero, with the absence grade retained in evidence.
- Percentage = obtained / maximum × 100. The supplied PDFs print one decimal place, so percentage and CGPA also use Excel `ROUND(value,1)`.
- Rounding is performed by **literal Excel formulas**. There is no Python `round()`, Decimal half-up, or substitute SGPA rounding function.
- Python uses rational arithmetic (`Fraction`) for exact numerators, denominators, credits and mark sums. The report retains those exact fractions alongside the Excel calculations.
- Passing year is taken specifically from **Year of Passing**, never the certificate issue date. The samples say 2025 even though their issue date is in 2026.

## Supported documents and accuracy limits

The parser is designed and regression-tested for the supplied **two-column, text-based MSU School of Design transcript format**. Both `pdfplumber` and `pypdf` must agree on the course numeric rows and key printed values. Course-code coverage, footers and semester sequence are also checked.

The grade legend is an image in the supplied PDFs. Its mapping was visually verified: **O=10, A+=9, A=8, B+=7, B=6, C=5, P=4, F=0, AB=0**. Its exact image-stream SHA-256 fingerprint is checked in incoming documents. A different/missing legend is flagged even if it might be semantically equivalent; a developer must inspect it before adding support. Grade boundaries are 99/90/80/70/60/50/40, with below 40 = F.

No system can promise perfect extraction for arbitrary or altered PDFs. Scans, encrypted or malformed PDFs, unfamiliar layouts, changed legends, missing data, parser disagreements and duplicate student records are flagged for **REVIEW REQUIRED**. This version deliberately does not use OCR guesses as verified data. Two text engines agreeing does not prove that a PDF's visible rendering is genuine or that it has not been tampered with. The report checks arithmetic and structure, not document authenticity or graduation eligibility.

The same student registration in multiple selected PDFs is flagged. The application treats each PDF as one complete student transcript, not as a set of pages to merge across files. Limits: 500 PDFs per batch, 50 MB per PDF and 20 pages per document. ZIPs are read without extracting archive paths; unrelated non-PDF entries are ignored.

Do not edit source cells in a completed audit and expect the extraction evidence or Python totals to be regenerated. Excel formulas recalculate, but code-produced values and diagnostics represent the original run. Re-run the application after changing a PDF.

## Included sample findings

The five supplied PDFs contain 122 courses in total. Their passing years, semester sequences, maximum marks, obtained marks and total credits reconcile. Three discrepancies were identified:

| Student | Check | PDF | Computed at one decimal |
|---|---|---:|---:|
| Aakriti Thakur | Semester 5 SGPA: 168 / 22 | 7.7 | 7.6 |
| Nayanika Ghosh | Semester 5 SGPA: 39 / 22 | 2.2 | 1.8 |
| Nayanika Ghosh | CGPA: 39 / 42 | 1.1 | 0.9 |

`Sample_Audit_2025.xlsx` is provided separately. Its formulas and preview were checked using the workbook-generation engine. Native desktop Excel could not run inside the development environment; open it in desktop Excel to recalculate with your target engine. The native GUI and Excel automation must receive a final smoke test on the destination Windows computer.

## Command line

After Setup.bat:

```bat
.venv\Scripts\python.exe app.py "D:\Transcripts\test.zip" --output "D:\Reports\Audit.xlsx"
```

Optional flags: `--json "D:\Reports\evidence.json"` exports the raw extraction evidence; `--no-excel` leaves formulas pending for manual Excel calculation.

## Tests

```bat
.venv\Scripts\python.exe -m unittest discover -s tests -v
set TRANSCRIPT_SAMPLES=D:\Transcripts\test.zip
.venv\Scripts\python.exe -m unittest discover -s tests -v
```

The second command sequence includes the original five-sample regression tests. Tests cover category precedence, every supported semester range, gaps/order/duplicates, grading boundaries, exact arithmetic, missing/invalid rows, zero and absent results, duplicate files/registrations, the 500-file cap, ZIP path safety, native ROUND formulas, missing-data gating and safe literal text in XLSX.

The development run passed 21 tests including the samples. A separate scale test exported 500 student records with 12,200 subject rows; this tested report generation, not 500 distinct PDF layouts or native Excel automation.

## Files

- `app.py`: native Windows desktop interface and command line.
- `checker.py`: extraction, coverage checks, categories and exact arithmetic.
- `report.py`: report formulas and template population using standard-library XML/ZIP.
- `report_template.xlsx`: styled four-sheet template; no student data.
- `recalculate.ps1`: private desktop Excel calculation and save.
- `tests/test_checker.py`: regression tests.

No runtime connection to a server, AI model or Codex is needed. Student PDFs are read locally. ZIP previews use temporary files that are removed when the application closes, unless another PDF viewer keeps a temporary file locked.

## Fix notes (v1.3)

A new **PDF Parser Cross-check** sheet was added, and the identity/text checks were made ligature-aware:

- Font ligatures (e.g. the printed "fi" stored as a single glyph, U+FB01) previously made pdfplumber and pypdf disagree on a student's name, which blocked SGPA/CGPA/percentage for that whole transcript even though the data was correct. These character-level differences are now recognised with Unicode NFKC normalization and **do not block calculations** - the transcript still calculates normally.
- Every character-level difference the two engines produced (ligatures or anything else) is still recorded, on its own row, in the new **PDF Parser Cross-check** sheet - alongside both engines' raw text - so nothing is hidden.
- If a difference does **not** disappear after normalization (a genuine mismatch, not just a glyph substitution), it is treated exactly as before: `Independent extraction disagrees on ...` is added to the transcript's issues and the transcript is still routed to REVIEW REQUIRED.
- Nothing about the **structural/numeric** checks changed: missing or out-of-order semesters, course-code coverage mismatches, footer disagreements, and any SGPA/CGPA/marks/percentage mismatch still behave exactly as in v1.2 - `MISMATCH`/`REVIEW REQUIRED` where warranted, with no exceptions.

## Fix notes (v1.2)

Two problems were reported in v1.1 and are fixed here:

1. **"REVIEW REQUIRED" gave no reason.** The pass/fail cells (Sequence check, Extraction check, Duplicate check, etc.) must stay exact literal values because other formulas test them with `="REVIEW REQUIRED"` / `="MISMATCH"`. Instead, the **Review details** column (Sheet 1) and **Calculation details** columns (Sheets 2 and 4) now build a *labeled* reason per flagged check, e.g. `Sequence check: observed semesters [1,2,3] do not match the expected Regular range [1,2,3,4,5,6]; Duplicate check: Duplicate registration in batch`, instead of one unlabelled list of every issue on the record. The **Grading legend** column now says specifically whether the legend image is *missing entirely* or *present but does not match the verified fingerprint*, instead of a bare `REVIEW REQUIRED`. Sheet 3 (Max marks checking) has no reason column of its own, so its "why" is appended to the semester-breakdown cell.
2. **Blank calculation cells.** A semester's SGPA was being left blank whenever *any other semester in the same transcript* had a problem, even if that semester's own data was perfectly clean. The gating now only withholds a semester's figures for that semester's own issues, or for a genuinely document-wide issue (unreadable file, identity mismatch, missing legend, course-code coverage mismatch) that really does make every semester's numbers suspect. Any cell that is still intentionally withheld now shows the text `REVIEW REQUIRED` instead of an empty cell, with the reason spelled out in the same row's details column, so a blank never looks like a bug.

Record-level CGPA and percentage (Sheet 4) are unchanged in one respect: they still require the *entire* transcript to be issue-free, because they are sums across every semester - if any semester's course data is unreliable, the CGPA and percentage genuinely can't be trusted either.

## Strict-audit build notes (v1.1)

- The GUI button is labelled **Save / Download Excel report...**; clicking it opens the normal Windows Save As dialog so you choose both the folder and filename.
- `RunTests.bat` runs the built-in regression tests. If a test fails, do not use the checker until the failure is reviewed.
- `VALIDATION_AND_RULES.md` maps the implemented checks directly to the audit rules.
