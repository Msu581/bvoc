"""Windows desktop application. Student PDFs never leave this computer."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import queue
import tempfile
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path

from checker import audit, discover, parse_pdf, mark_duplicates, exact, to_dict
from report import export, check

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('Transcript Checker - Strict Audit Mode')
        self.geometry('1220x820')
        self.minsize(1000,680)
        self.configure(bg='#f3f5f9')
        self.records=[]
        self.sources=[]
        self.events=queue.Queue()
        self.busy=False
        self.cancel_event=threading.Event()
        self.preview_dir=tempfile.TemporaryDirectory(prefix='transcript-preview-')
        style=ttk.Style(self)
        style.theme_use('clam')
        style.configure('.',font=('Segoe UI',10))
        style.configure('TFrame',background='#f3f5f9')
        style.configure('TLabel',background='#f3f5f9',foreground='#182235')
        style.configure('Title.TLabel',font=('Segoe UI',23,'bold'))
        style.configure('TButton',padding=(14,9))
        style.configure('Accent.TButton',background='#214a89',foreground='white')
        style.configure('Treeview',rowheight=32,font=('Segoe UI',10))
        style.configure('Treeview.Heading',font=('Segoe UI',10,'bold'))
        main=ttk.Frame(self,padding=24)
        main.pack(fill='both',expand=True)
        ttk.Label(main,text='Transcript Checker',style='Title.TLabel').pack(anchor='w')
        ttk.Label(main,text='B.Voc and B.Des  /  Passing year 2025  /  Up to 500 PDFs per batch').pack(anchor='w',pady=(4,18))
        ttk.Label(main,text='1. Choose PDFs, a ZIP, or a folder. You can also paste paths below, one per line.').pack(anchor='w')
        bar=ttk.Frame(main)
        bar.pack(fill='x',pady=8)
        self.add_button=ttk.Button(bar,text='Add PDFs / ZIP',command=self.add_files)
        self.add_button.pack(side='left')
        self.folder_button=ttk.Button(bar,text='Add folder',command=self.add_folder)
        self.folder_button.pack(side='left',padx=8)
        self.clear_button=ttk.Button(bar,text='Clear',command=self.clear)
        self.clear_button.pack(side='left')
        self.paths=tk.Text(main,height=3,font=('Segoe UI',10),relief='solid',bd=1,padx=10,pady=8)
        self.paths.pack(fill='x')
        actions=ttk.Frame(main)
        actions.pack(fill='x',pady=(12,8))
        self.run_button=ttk.Button(actions,text='2. Check PDFs',style='Accent.TButton',command=self.run)
        self.run_button.pack(side='left')
        self.cancel_button=ttk.Button(actions,text='Cancel',command=self.cancel_event.set,state='disabled')
        self.cancel_button.pack(side='left',padx=8)
        self.save_button=ttk.Button(actions,text='3. Save / Download Excel report...',command=self.save,state='disabled')
        self.save_button.pack(side='right')
        self.progress=ttk.Progressbar(main,mode='determinate')
        self.progress.pack(fill='x',pady=(0,6))
        self.status=tk.StringVar(value='Ready. Files are processed locally; nothing is uploaded.')
        ttk.Label(main,textvariable=self.status,wraplength=1120).pack(anchor='w',pady=(0,8))
        panel=ttk.Frame(main)
        panel.pack(fill='both',expand=True)
        cols=('name','reg','category','sem','extraction','checks')
        self.tree=ttk.Treeview(panel,columns=cols,show='headings',selectmode='browse',height=8)
        for key,title,width in zip(cols,['Student','Registration','Category','Semesters','Extraction','Arithmetic'],[165,160,190,125,145,210]):
            self.tree.heading(key,text=title)
            self.tree.column(key,width=width,minwidth=90)
        self.tree.pack(side='left',fill='both',expand=True)
        scroll=ttk.Scrollbar(panel,orient='vertical',command=self.tree.yview)
        scroll.pack(side='right',fill='y')
        self.tree.configure(yscrollcommand=scroll.set)
        self.tree.tag_configure('review',foreground='#9a4b0b')
        self.tree.bind('<<TreeviewSelect>>',self.select)
        self.detail=tk.Text(main,height=7,font=('Consolas',10),wrap='word',relief='solid',bd=1,padx=10,pady=8,state='disabled')
        self.detail.pack(fill='x',pady=(12,8))
        bottom=ttk.Frame(main)
        bottom.pack(fill='x')
        ttk.Button(bottom,text='Open selected source PDF',command=self.open_source).pack(side='left')
        ttk.Label(bottom,text='ROUND checks run in desktop Excel. Uncertain extraction always requires review.').pack(side='right')
        self.after(100,self.poll)
        self.protocol('WM_DELETE_WINDOW',self.close)

    def append_paths(self,values):
        current=self.paths.get('1.0','end').strip()
        self.paths.delete('1.0','end')
        self.paths.insert('1.0','\n'.join(([current] if current else [])+list(values)))

    def add_files(self):
        self.append_paths(filedialog.askopenfilenames(title='Choose PDFs or ZIP archives',filetypes=[('PDFs and ZIP archives','*.pdf *.zip'),('All files','*.*')]))

    def add_folder(self):
        p=filedialog.askdirectory(title='Choose folder (subfolders included)')
        if p:self.append_paths([p])

    def clear(self):
        self.paths.delete('1.0','end')
        self.records=[]
        self.sources=[]
        self.tree.delete(*self.tree.get_children())
        self.save_button.configure(state='disabled')
        self.status.set('Ready. Files are processed locally; nothing is uploaded.')

    def set_busy(self,on):
        self.busy=on
        for b in (self.run_button,self.add_button,self.folder_button,self.clear_button):
            b.configure(state='disabled' if on else 'normal')
        self.paths.configure(state='disabled' if on else 'normal')
        self.save_button.configure(state='normal' if not on and self.records else 'disabled')

    def run(self):
        paths=self.paths.get('1.0','end').splitlines()
        self.records=[]
        self.tree.delete(*self.tree.get_children())
        self.cancel_event.clear()
        self.set_busy(True)
        self.cancel_button.configure(state='normal')
        self.status.set('Finding PDF files...')
        def worker():
            try:
                sources=discover(paths)
                self.events.put(('sources',sources))
                for i,src in enumerate(sources):
                    if self.cancel_event.is_set():
                        self.events.put(('cancelled',None))
                        return
                    self.events.put(('record',(i+1,len(sources),parse_pdf(src))))
                self.events.put(('done',None))
            except Exception as exc:self.events.put(('error',str(exc)))
        threading.Thread(target=worker,daemon=True).start()

    def poll(self):
        try:
            while True:
                kind,payload=self.events.get_nowait()
                if kind=='sources':self.sources=payload
                elif kind=='record':
                    i,total,r=payload
                    self.records.append(r)
                    self.progress.configure(maximum=total,value=i)
                    self.tree.insert('', 'end',iid=str(i-1),values=(r.name or '(unreadable)',r.registration,r.category,', '.join(map(str,r.observed_semesters)),'Extracted' if r.complete else 'REVIEW REQUIRED','Pending Excel ROUND'),tags=() if r.complete else ('review',))
                    self.status.set(f'Extracted {i} of {total}: {r.name or r.source}')
                elif kind in ('done','cancelled'):
                    if kind=='cancelled':
                        self.records=[]
                        self.tree.delete(*self.tree.get_children())
                        self.status.set('Cancelled. No partial batch report will be exported.')
                    else:
                        mark_duplicates(self.records)
                        for i,r in enumerate(self.records):
                            if r.duplicate_issues:
                                self.tree.set(str(i),'extraction','REVIEW REQUIRED')
                                self.tree.item(str(i),tags=('review',))
                        self.status.set(f'{len(self.records)} PDFs checked. Save the report to run Excel formulas and review all four sheets.')
                    self.set_busy(False)
                    self.cancel_button.configure(state='disabled')
                elif kind=='saved':
                    path,ok,detail=payload
                    self.set_busy(False)
                    if ok:
                        self.status.set('Report saved. Native Excel recalculated all formulas: '+str(path))
                        self.load_statuses(path)
                        messagebox.showinfo('Report saved','Excel report saved and recalculated:\n'+str(path))
                    else:
                        self.status.set('Report saved. Open it in desktop Excel to calculate ROUND and final results.')
                        messagebox.showwarning('Open the report in Excel','Report saved:\n'+str(path)+'\n\nExcel could not be started automatically. Formula cells show PENDING EXCEL until you open the workbook in desktop Excel with calculation set to Automatic (or press Ctrl+Alt+F9), then save.\n\n'+detail)
                elif kind=='error':
                    self.set_busy(False)
                    self.cancel_button.configure(state='disabled')
                    self.status.set('Could not complete the operation.')
                    messagebox.showerror('Operation failed',payload)
        except queue.Empty:pass
        self.after(100,self.poll)

    def load_statuses(self,path):
        import zipfile
        from xml.etree import ElementTree as ET
        ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        with zipfile.ZipFile(path) as z:
            shared=[]
            if 'xl/sharedStrings.xml' in z.namelist():
                shared=[''.join(t.text or '' for t in si.findall('.//m:t',ns)) for si in ET.fromstring(z.read('xl/sharedStrings.xml'))]
            root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
            for i in range(len(self.records)):
                c=root.find(f'.//m:c[@r="M{i+6}"]',ns)
                v=c.find('m:v',ns) if c is not None else None
                value=v.text if v is not None else 'REVIEW REQUIRED'
                if c is not None and c.get('t')=='s':value=shared[int(value)]
                self.tree.set(str(i),'checks',value)

    def select(self,event=None):
        sel=self.tree.selection()
        if not sel:return
        r=self.records[int(sel[0])]
        lines=[f'{r.name} | {r.registration} | {r.programme}',f'Category: {r.category_raw}. Sequence: {r.sequence_status}. Passing year: {r.passing_year}.',f'Courses: {r.course_count}; maximum: {r.course_count*100}; obtained: {exact(r.marks)}; credits: {exact(r.credits)}.']
        for s in r.semesters:
            lines.append(f'Sem {s.number}: credits {exact(s.credits)} (PDF {s.printed_credits}); SGPA {exact(s.weighted)}/{exact(s.credits)} (PDF {s.printed_sgpa}).')
        lines += r.all_issues()
        self.detail.configure(state='normal')
        self.detail.delete('1.0','end')
        self.detail.insert('1.0','\n'.join(lines))
        self.detail.configure(state='disabled')

    def save(self):
        path=filedialog.asksaveasfilename(title='Save Excel report',defaultextension='.xlsx',initialfile='Transcript_Audit_2025.xlsx',filetypes=[('Excel workbook','*.xlsx')],confirmoverwrite=True)
        if not path:return
        self.set_busy(True)
        self.status.set('Writing four-sheet report and starting native Excel recalculation...')
        def worker():
            try:
                ok,detail=export(self.records,path)
                self.events.put(('saved',(path,ok,detail)))
            except Exception as exc:self.events.put(('error',str(exc)))
        threading.Thread(target=worker,daemon=True).start()

    def open_source(self):
        sel=self.tree.selection()
        if not sel:return
        try:
            i=int(sel[0]);src=self.sources[i];r=self.records[i]
            data=src.read()
            if hashlib.sha256(data).hexdigest()!=r.sha256:
                raise ValueError('The source file changed after checking. Run the batch again.')
            if src.member:
                p=Path(self.preview_dir.name)/(r.sha256+'.pdf')
                p.write_bytes(data)
            else:p=Path(src.path)
            os.startfile(str(p))
        except Exception as exc:messagebox.showerror('Cannot open PDF',str(exc))

    def close(self):
        if self.busy:
            messagebox.showinfo('Operation in progress','Wait for saving to finish, or cancel PDF processing before closing.')
            return
        try:self.preview_dir.cleanup()
        except PermissionError:pass
        self.destroy()

def main():
    parser=argparse.ArgumentParser(description='Local MSU transcript batch checker')
    parser.add_argument('paths',nargs='*',help='PDF, ZIP or folder paths')
    parser.add_argument('--output',type=Path,help='Export without opening the GUI')
    parser.add_argument('--json',type=Path,help='Optional extraction evidence JSON')
    parser.add_argument('--no-excel',action='store_true',help='Leave ROUND formulas pending until the workbook is opened in Excel')
    args=parser.parse_args()
    if args.output:
        if not args.paths:parser.error('Provide at least one PDF, ZIP or folder')
        records=audit(args.paths,lambda i,n,r:print(f'{i}/{n}: {r.name or r.source}',flush=True))
        if args.json:args.json.write_text(json.dumps(to_dict(records),indent=2),encoding='utf-8')
        ok,note=export(records,args.output,native=not args.no_excel)
        print(note)
        print('Saved:',args.output)
    else:
        app=App()
        if args.paths:app.append_paths(args.paths)
        app.mainloop()

if __name__=='__main__':main()
