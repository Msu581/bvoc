"""Four-sheet report from an Artifact Tool authored template.

Rounding is deliberately delegated to real Excel ROUND formulas. No Python
round, half-up or replacement rounding algorithm is used anywhere.
"""
from __future__ import annotations
import json
import math
import os
import subprocess
import tempfile
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from checker import exact, decimal_text, number, POINTS

SHEETS = ['Year of passing check','SGPA and credit check','Max marks checking','Calculations']
HEADERS = [
 ['Student name','Registration','Category','Programme','PDF passing year','Expected year','Year check','Observed semesters','Expected semesters','Sequence check','Extraction check','Duplicate check','Overall check','Source file','SHA-256','Review details','Grading legend'],
 ['Student name','Registration','Category','Semester','PDF credits','Code credits','Excel credits','Credit check','Code weighted points','Excel weighted points','Exact SGPA fraction','Unrounded SGPA','PDF SGPA','Excel ROUND(SGPA,1)','SGPA check','Marks / grade check','Extraction check','PDF page','Source file','Calculation details'],
 ['Student name','Registration','Category','Unique courses','Computed max marks','PDF max marks','Max marks check','Code obtained marks','Excel obtained marks','PDF obtained marks','Obtained marks check','Semester breakdown','Extraction check','Source file'],
 ['Student name','Registration','Category','Code total credits','Excel total credits','PDF total credits','Total credit check','Code weighted points','Excel weighted points','Exact CGPA fraction','Unrounded CGPA','Excel ROUND(CGPA,1)','PDF CGPA','CGPA check','Computed obtained marks','Computed max marks','Unrounded percentage','Excel ROUND(percent,1)','PDF percentage','Percentage check','Overall check','Calculation details','Source file']
]
DETAIL_HEADERS = ['Student name','Registration','Category','Semester','Course code','Course title excerpt','T credit','P credit','PR credit','Excel course credits','Marks','PDF grade','Grade from marks','Grade points','Excel weighted points','Marks / grade check','PDF page','Source file','Source row','Review details']
NOTES = [
 'Expected passing year: 2025. MATCH checks arithmetic and structure, not graduation eligibility. Review flagged files.',
 'SGPA = SUM(course credits x printed-grade points) / SUM(course credits). Rounding: Excel ROUND(value,1). Course evidence below.',
 'Maximum marks = sum of unique course counts within each semester x 100. Duplicate rows are flagged for review.',
 'CGPA uses unrounded subject-weighted points / total credits. Percentage = obtained / maximum x 100; both use Excel ROUND(value,1).'
]

def col(i):
    s = ''
    while i:
        i,r = divmod(i-1,26)
        s = chr(65+r)+s
    return s

def num(x):
    if x is None:
        return None
    f = number(x)
    return f.numerator if f.denominator == 1 else float(f)

def fx(formula):
    return {'formula': formula}

def check(printed, computed, ready=True):
    if not ready or printed is None:
        return 'REVIEW REQUIRED'
    return 'MATCH' if number(printed)==number(computed) else 'MISMATCH'

def compare(formula, ready=True):
    return fx(f'=IF({formula},"MATCH","MISMATCH")') if ready else 'REVIEW REQUIRED'

def sum_cells(refs):
    return 'SUM('+','.join(refs)+')' if refs else '0'

def build_model(records):
    sem_count = sum(len(r.semesters) or 1 for r in records)
    detail_title_row = 8 + sem_count
    detail_header_row = detail_title_row + 2
    detail_start = detail_header_row + 1
    model = []
    for name,headers,note in zip(SHEETS,HEADERS,NOTES):
        model.append({'name':name,'headers':headers,'note':note,'rows':{},'summary_end':5})
    def put(sheet,row,values):
        model[sheet]['rows'][str(row)] = values
    def identity(r):
        return [r.name or '(unreadable)',r.registration,r.category]
    put(1,detail_title_row,['Course evidence and calculation inputs'])
    put(1,detail_title_row+1,['Legend verified against the supplied PDF image: O=10, A+=9, A=8, B+=7, B=6, C=5, P=4, F=0, AB=0.'])
    put(1,detail_header_row,DETAIL_HEADERS)
    model[1]['detail_header'] = detail_header_row
    model[1]['detail_start'] = detail_start
    sem_row = 6
    detail_row = detail_start
    for idx,r in enumerate(records,6):
        ids = identity(r)
        ready = r.complete
        doc_ready = not r.issues  # document-wide problems (unreadable file, identity mismatch, missing legend, code-coverage mismatch, etc.) make every semester's numbers suspect; a problem confined to ONE semester should not blank out the others.
        ext = 'MATCH' if ready else 'REVIEW REQUIRED'
        duplicate = 'REVIEW REQUIRED' if r.duplicate_issues else 'MATCH'
        sem_rows = []
        all_course_ranges = []
        for s in r.semesters:
            start = detail_row
            for c in s.courses:
                d = detail_row
                put(1,d,ids+[s.number,c.code,c.name,num(c.t),num(c.p),num(c.pr),fx(f'=SUM(G{d}:I{d})'),num(c.obtained),c.grade,c.expected,POINTS.get(c.grade),fx(f'=J{d}*N{d}'),compare(f'L{d}=M{d}',c.grade in POINTS),c.page,r.source,c.raw,'; '.join(c.issues)])
                detail_row += 1
            stop = detail_row-1
            sr = sem_row
            sem_rows.append(sr)
            sem_ready = doc_ready and not s.issues and bool(s.courses) and s.credits>0
            crange = f'J{start}:J{stop}' if s.courses else None
            wrange = f'O{start}:O{stop}' if s.courses else None
            if s.courses:
                all_course_ranges.append((start,stop))
            grade_status = 'MISMATCH' if any(c.issues for c in s.courses) else ('MATCH' if sem_ready else 'REVIEW REQUIRED')
            # Why this semester's figures are withheld, when they are: its own problem, or a document-wide problem elsewhere.
            if s.issues:
                withheld_reason = '; '.join(s.issues)
            elif not doc_ready:
                withheld_reason = 'Withheld: this semester itself checks out, but a document-wide issue elsewhere makes every semester in this transcript unreliable - '+'; '.join(r.issues)
            elif not s.courses:
                withheld_reason = 'No course rows extracted for this semester'
            elif s.credits<=0:
                withheld_reason = 'Total course credits for this semester are zero'
            else:
                withheld_reason = ''
            calc_text = f'{exact(s.weighted)} / {exact(s.credits)} = '+(decimal_text(s.weighted/s.credits) if s.credits else 'undefined')
            if withheld_reason:
                calc_text += '; '+withheld_reason
            put(1,sr,ids+[s.number,num(s.printed_credits),num(s.credits),
                fx('=SUM('+crange+')') if crange else 'REVIEW REQUIRED',
                compare(f'AND(E{sr}=F{sr},F{sr}=G{sr})',sem_ready and s.printed_credits is not None),
                num(s.weighted),fx('=SUM('+wrange+')') if wrange else 'REVIEW REQUIRED',
                exact(s.weighted/s.credits) if s.credits else 'REVIEW REQUIRED',
                fx(f'=J{sr}/G{sr}') if sem_ready else 'REVIEW REQUIRED',num(s.printed_sgpa),
                fx(f'=ROUND(L{sr},1)') if sem_ready else 'REVIEW REQUIRED',
                compare(f'AND(M{sr}=N{sr},I{sr}=J{sr})',sem_ready and s.printed_sgpa is not None),
                grade_status,'MATCH' if sem_ready else 'REVIEW REQUIRED',s.page,r.source,
                calc_text])
            sem_row += 1
        if not sem_rows:
            no_sem_reason = 'REVIEW REQUIRED: no semester tables extracted'+('; '.join(['']+r.issues) if r.issues else '')
            put(1,sem_row,ids+[None,None,'REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED',None,'REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED','REVIEW REQUIRED',None,r.source,no_sem_reason])
            sem_rows.append(sem_row)
            sem_row += 1
        refs = lambda letter: [f"'{SHEETS[1]}'!{letter}{n}" for n in sem_rows]
        course_sum = lambda letter: sum_cells([f"'{SHEETS[1]}'!{letter}{a}:{letter}{b}" for a,b in all_course_ranges])
        max_marks = r.course_count*100
        breakdown = '; '.join(f'S{s.number}: {len(set(c.code for c in s.courses))} courses, {exact(s.marks)} marks' for s in r.semesters)
        if ext != 'MATCH':
            breakdown += (' | ' if breakdown else '')+'REVIEW REQUIRED: '+('; '.join(r.all_issues()) if r.all_issues() else 'unresolved extraction issue - see Year of passing check sheet')
        put(2,idx,ids+[r.course_count,fx(f'=D{idx}*100'),num(r.printed.get('max_marks')),
            compare(f'E{idx}=F{idx}',ready and r.printed.get('max_marks') is not None),num(r.marks),fx('='+course_sum('K')),
            num(r.printed.get('obtained')),compare(f'AND(H{idx}=I{idx},I{idx}=J{idx})',ready and r.printed.get('obtained') is not None),
            breakdown,ext,r.source])
        total_credits_formula = '='+course_sum('J')
        total_weighted_formula = '='+course_sum('O')
        calc_summary = f'CGPA: {exact(r.weighted)}/{exact(r.credits)}. Percentage: {exact(r.marks)}/{max_marks}*100.'
        if not ready:
            calc_summary += ' REVIEW REQUIRED - unrounded/rounded CGPA and percentage withheld until these are resolved: '+('; '.join(r.all_issues()) if r.all_issues() else 'unresolved extraction issue')
        elif r.all_issues():
            calc_summary += ' '+'; '.join(r.all_issues())
        put(3,idx,ids+[num(r.credits),fx(total_credits_formula),num(r.printed.get('credits')),
            compare(f'AND(D{idx}=E{idx},E{idx}=F{idx})',ready and r.printed.get('credits') is not None),num(r.weighted),fx(total_weighted_formula),
            exact(r.weighted/r.credits) if r.credits else 'REVIEW REQUIRED',
            fx(f'=I{idx}/E{idx}') if ready and r.credits else 'REVIEW REQUIRED',
            fx(f'=ROUND(K{idx},1)') if ready and r.credits else 'REVIEW REQUIRED',num(r.printed.get('cgpa')),
            compare(f'AND(L{idx}=M{idx},H{idx}=I{idx})',ready and r.credits>0 and r.printed.get('cgpa') is not None),
            fx('='+course_sum('K')),max_marks,
            fx(f'=O{idx}/P{idx}*100') if ready and max_marks else 'REVIEW REQUIRED',
            fx(f'=ROUND(Q{idx},1)') if ready and max_marks else 'REVIEW REQUIRED',num(r.printed.get('percentage')),
            compare(f'R{idx}=S{idx}',ready and max_marks>0 and r.printed.get('percentage') is not None),
            fx(f"='{SHEETS[0]}'!M{idx}"),
            calc_summary,r.source])
        checks = [f'G{idx}',f'J{idx}',f'K{idx}',f'L{idx}'] + refs('H')+refs('O')+refs('P')+refs('Q') + [f"'{SHEETS[2]}'!G{idx}",f"'{SHEETS[2]}'!K{idx}",f"'{SHEETS[3]}'!G{idx}",f"'{SHEETS[3]}'!N{idx}",f"'{SHEETS[3]}'!T{idx}"]
        mismatches = ','.join(x+'="MISMATCH"' for x in checks)
        reviews = ','.join(x+'="REVIEW REQUIRED"' for x in checks)
        overall = fx(f'=IF(OR({mismatches}),"MISMATCH",IF(OR({reviews}),"REVIEW REQUIRED","MATCH"))')
        # Build one reason per flagged check, clearly labeled, instead of dumping every issue into one blob -
        # so a reviewer can see exactly which column's REVIEW REQUIRED/MISMATCH it explains.
        review_parts = []
        if r.passing_year is None:
            review_parts.append('Year check: Year of Passing was not found in the document')
        if r.sequence_status != 'MATCH':
            if not r.expected_semesters or not r.semesters:
                review_parts.append('Sequence check: programme/category could not be determined, or no semester tables were extracted, so the expected semester range is unknown')
            else:
                review_parts.append(f'Sequence check: observed semesters [{", ".join(map(str,r.observed_semesters))}] do not match the expected {r.category} range [{", ".join(map(str,r.expected_semesters))}]')
        if ext != 'MATCH':
            extraction_detail = r.issues + [f'Sem {s.number}: {e}' for s in r.semesters for e in s.issues] + [f'Sem {s.number} {c.code}: {e}' for s in r.semesters for c in s.courses for e in c.issues]
            review_parts.append('Extraction check: '+('; '.join(extraction_detail) if extraction_detail else 'unspecified extraction issue'))
        if duplicate != 'MATCH':
            review_parts.append('Duplicate check: '+('; '.join(r.duplicate_issues) if r.duplicate_issues else 'duplicate detected'))
        legend_ok = bool(r.legend_page)
        if not legend_ok:
            legend_reason = ('legend image is present but its fingerprint does not match the verified sample (different or altered legend)'
                              if r.legend_any_image_seen else 'no grading legend image was found in the document at all')
            review_parts.append('Grading legend: '+legend_reason)
            legend_cell = 'REVIEW REQUIRED: '+legend_reason
        else:
            legend_cell = f'Verified image on page {r.legend_page}'
        put(0,idx,ids+[r.programme,num(r.passing_year),2025,compare(f'E{idx}=F{idx}',r.passing_year is not None),
            ', '.join(map(str,r.observed_semesters)),', '.join(map(str,r.expected_semesters)),r.sequence_status,ext,duplicate,overall,r.source,r.sha256,
            '; '.join(review_parts),legend_cell])
    for i in (0,2,3):
        model[i]['summary_end'] = 5+len(records)
    model[1]['summary_end'] = sem_row-1
    return model

NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
ET.register_namespace('',NS)
def tag(name):
    return '{'+NS+'}'+name

def write_xlsx(records, destination):
    """Populate the styled template with literal-safe cells and native formulas."""
    template = Path(__file__).with_name('report_template.xlsx')
    if not template.exists():
        raise FileNotFoundError('report_template.xlsx is missing. Keep the application folder together.')
    destination = Path(destination)
    if destination.suffix.lower() != '.xlsx':
        raise ValueError('Report filename must end in .xlsx')
    model = build_model(records)
    destination.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp = tempfile.mkstemp(suffix='.xlsx',prefix='.transcript-',dir=destination.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(template) as zin, zipfile.ZipFile(tmp,'w',zipfile.ZIP_DEFLATED) as zout:
            for item in zin.infolist():
                content = zin.read(item.filename)
                if item.filename == 'xl/workbook.xml':
                    root = ET.fromstring(content)
                    calc = root.find(tag('calcPr'))
                    if calc is None: calc = ET.SubElement(root,tag('calcPr'))
                    calc.attrib.update({'calcMode':'auto','fullCalcOnLoad':'1','forceFullCalc':'1'})
                    content = ET.tostring(root,encoding='utf-8',xml_declaration=True)
                for i,s in enumerate(model,1):
                    if item.filename != f'xl/worksheets/sheet{i}.xml': continue
                    root = ET.fromstring(content)
                    data = root.find(tag('sheetData'))
                    body = data.find(f"{tag('row')}[@r='6']")
                    styles = {re_col(c.get('r')):c.get('s','0') for c in body} if body is not None else {}
                    header = data.find(f"{tag('row')}[@r='5']")
                    header_styles = {re_col(c.get('r')):c.get('s','0') for c in header} if header is not None else {}
                    note_row=data.find(f"{tag('row')}[@r='3']")
                    note_styles={re_col(c.get('r')):c.get('s','0') for c in note_row} if note_row is not None else {}
                    widths={}
                    for width in root.findall(f'{tag("cols")}/{tag("col")}'):
                        for ci in range(int(width.get('min')),int(width.get('max'))+1):
                            widths[ci]=float(width.get('width','19'))
                    for row in list(data):
                        if int(row.get('r'))>=6: data.remove(row)
                    for rid,values in sorted(s['rows'].items(),key=lambda x:int(x[0])):
                        is_note=int(rid) in (s.get('detail_header',0)-2,s.get('detail_header',0)-1)
                        lines=max([1]+[sum(max(1,math.ceil(len(line)/max(8,widths.get(j+1,19)-2))) for line in v.split('\n')) for j,v in enumerate(values) if isinstance(v,str)])
                        height=42 if is_note else min(409,max(42,lines*14+10))
                        row = ET.SubElement(data,tag('row'),{'r':rid,'ht':str(height),'customHeight':'1'})
                        for cidx,value in enumerate(values,1):
                            if value is None: continue
                            letter = col(cidx)
                            stylemap = header_styles if int(rid)==s.get('detail_header') else note_styles if is_note else styles
                            cell = ET.SubElement(row,tag('c'),{'r':letter+rid,'s':stylemap.get(letter,'0')})
                            if isinstance(value,dict):
                                ET.SubElement(cell,tag('f')).text=value['formula'].lstrip('=')
                                cell.set('t','str')
                                ET.SubElement(cell,tag('v')).text='PENDING EXCEL'
                            elif isinstance(value,(int,float)):
                                ET.SubElement(cell,tag('v')).text=str(value)
                            else:
                                cell.set('t','inlineStr')
                                st=ET.SubElement(ET.SubElement(cell,tag('is')),tag('t'))
                                st.set('{http://www.w3.org/XML/1998/namespace}space','preserve')
                                st.text=clean_text(str(value))
                    dimension = root.find(tag('dimension'))
                    if dimension is None:
                        dimension=ET.Element(tag('dimension'))
                        index=1 if root.find(tag('sheetPr')) is not None else 0
                        root.insert(index,dimension)
                    dimension.set('ref',f'A1:{col(len(s["headers"]))}{max(map(int,s["rows"]))}')
                    filt=root.find(tag('autoFilter'))
                    if filt is None:
                        filt=ET.Element(tag('autoFilter'))
                        root.insert(list(root).index(data)+1,filt)
                    filt.set('ref',f'A5:{col(len(s["headers"]))}{s["summary_end"]}')
                    pane=root.find(f'.//{tag("pane")}')
                    if pane is not None:
                        pane.attrib.update({'xSplit':'3','ySplit':'5','topLeftCell':'D6','activePane':'bottomRight','state':'frozen'})
                    for cf in root.findall(tag('conditionalFormatting')):
                        cf.set('sqref',f'A6:{col(len(s["headers"]))}{max(map(int,s["rows"]))}')
                    content=ET.tostring(root,encoding='utf-8',xml_declaration=True)
                zout.writestr(item,content)
        os.replace(tmp,destination)
    except Exception:
        Path(tmp).unlink(missing_ok=True)
        raise
    return model

def re_col(ref):
    return ''.join(x for x in ref if x.isalpha())

def clean_text(value):
    return ''.join(c for c in value if c in '\n\r\t' or ord(c)>=32)[:32767]

def recalculate_in_excel(path,timeout=600):
    """A private Excel instance. Never attaches to or closes the user's workbook."""
    if os.name!='nt':
        return False,'Native recalculation requires Windows desktop Excel. Open the report in Excel.'
    script = Path(__file__).with_name('recalculate.ps1')
    try:
        p=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-ExecutionPolicy','Bypass','-File',str(script),'-WorkbookPath',str(Path(path).resolve())],capture_output=True,text=True,timeout=timeout,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        if p.returncode:
            return False,(p.stderr or p.stdout).strip()[-1600:]
        return True,p.stdout.strip()
    except Exception as exc:
        return False,str(exc)

def export(records,path,native=True):
    write_xlsx(records,path)
    if native:
        return recalculate_in_excel(path)
    return False,'Native calculation skipped. Open in desktop Excel to evaluate ROUND and all formula checks.'
