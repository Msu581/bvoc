import copy
import os
import sys
import tempfile
import unittest
import zipfile
from fractions import Fraction
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from checker import *
from report import build_model, write_xlsx, NS

def fixture():
    r=Transcript('fixture.pdf',sha256='a'*64,name='Test Student',registration='000123456789012345',category_raw='Lateral Entry to Third Year',category='Lateral to Third Year',programme='B.Voc',passing_year='2025',expected_semesters=[5,6],legend_page=2)
    r.semesters=[parse_block(n,1,100+n,0,'Course Code Course Name Credits (T-P-PR) Marks Grade\nIDL100 Design 3-0-0 80 A\nCREDITS: 3 SGPA: 8.0') for n in [5,6]]
    r.printed={'max_marks':'200','obtained':'160','credits':'6','percentage':'80.0','cgpa':'8.0'}
    return r

class RulesTests(unittest.TestCase):
    def test_all_categories(self):
        for raw,start in [('Regular',1),('Lateral Entry to Second Year',3),('Regular (Lateral Entry to Second Year)',3),('Lateral Entry to Third Year',5),('Regular (Lateral Entry to Third Year)',5)]:
            self.assertEqual(category(raw)[1],start)
        self.assertIsNone(category('Not Regular')[1])

    def test_programme_lengths(self):
        self.assertEqual(programme('Bachelor of Vocation')[1],6)
        self.assertEqual(programme('Bachelor of Design')[1],8)

    def test_gaps_extras_order_and_duplicates(self):
        r=fixture();self.assertEqual(r.sequence_status,'MATCH')
        for actual in [[5],[6,5],[5,5,6],[1,2,3,4,5,6],[5,6,7]]:
            x=copy.deepcopy(r)
            x.semesters=[Semester(n,1,0,0) for n in actual]
            self.assertEqual(x.sequence_status,'MISMATCH')

    def test_regular_bdes_and_all_lateral_ranges(self):
        for start,end in [(1,6),(3,6),(5,6),(1,8),(3,8),(5,8)]:
            r=fixture();r.expected_semesters=list(range(start,end+1));r.semesters=[Semester(n,1,0,0) for n in range(start,end+1)]
            self.assertEqual(r.sequence_status,'MATCH')
            r.semesters.pop(1)
            self.assertEqual(r.sequence_status,'MISMATCH')

    def test_grade_boundaries(self):
        for m,g in [(0,'F'),(39,'F'),(40,'P'),(49,'P'),(50,'C'),(59,'C'),(60,'B'),(69,'B'),(70,'B+'),(79,'B+'),(80,'A'),(89,'A'),(90,'A+'),(98,'A+'),(99,'O'),(100,'O')]:
            self.assertEqual(expected_grade(m),g)
        with self.assertRaises(ValueError):expected_grade(101)

    def test_exact_arithmetic_no_float_accumulation(self):
        c=Course('IDL100','Design','0.1','0.2','0','80','A',1,'')
        self.assertEqual(c.credits,Fraction(3,10))
        self.assertEqual(c.weighted,Fraction(12,5))

    def test_duplicate_course_is_never_silent(self):
        s=parse_block(1,1,0,0,'IDL100 Test 3-0-0 80 A\nIDL100 Test 3-0-0 80 A\nCREDITS: 6 SGPA: 8.0')
        self.assertTrue(any('Duplicate' in i for i in s.issues))

    def test_unparsed_course_and_unknown_grade(self):
        for body in ['IDL100 Test 3-0-0 XX A','IDL100 Test 3-0-0 80 X']:
            s=parse_block(1,1,0,0,body+'\nCREDITS: 3 SGPA: 8.0')
            self.assertTrue(s.issues)

    def test_zero_sgpa_and_absence_are_not_missing(self):
        s=parse_block(1,1,0,0,'IDL100 Test 3-0-0 0 F\nIDL101 Test 0-2-0 AB AB\nCREDITS: 5 SGPA: 0.0')
        self.assertFalse(s.issues)
        self.assertEqual(s.printed_sgpa,'0.0')
        self.assertEqual(s.marks,0)
        self.assertEqual(s.weighted,0)

    def test_marks_grade_disagreement(self):
        s=parse_block(1,1,0,0,'IDL100 Test 3-0-0 99 A\nCREDITS: 3 SGPA: 8.0')
        self.assertTrue(s.courses[0].issues)

    def test_missing_footer(self):
        self.assertTrue(parse_block(1,1,0,0,'IDL100 Test 3-0-0 80 A').issues)

    def test_duplicate_documents_and_registration(self):
        a=fixture();b=copy.deepcopy(a);mark_duplicates([a,b])
        self.assertEqual(len(a.duplicate_issues),2)
        b.sha256='b'*64;mark_duplicates([a,b])
        self.assertEqual(len(a.duplicate_issues),1)

    def test_500_limit_not_truncated(self):
        with tempfile.TemporaryDirectory() as d:
            for i in range(500):Path(d,f'{i}.pdf').touch()
            self.assertEqual(len(discover([d])),500)
            Path(d,'extra.pdf').touch()
            with self.assertRaises(ValueError):discover([d])

    def test_zip_does_not_extract_paths(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d,'samples.zip')
            with zipfile.ZipFile(path,'w') as z:z.writestr('../../escape.pdf',b'bad PDF')
            src=discover([path])[0]
            self.assertEqual(src.read(),b'bad PDF')
            r=parse_pdf(src)
            self.assertFalse(r.complete)
            self.assertEqual(len(list(Path(d).iterdir())),1)

class ReportTests(unittest.TestCase):
    def test_native_round_formulas_not_python_rounding(self):
        m=build_model([fixture()])
        self.assertEqual(m[1]['rows']['6'][13],{'formula':'=ROUND(L6,1)'})
        self.assertEqual(m[3]['rows']['6'][11],{'formula':'=ROUND(K6,1)'})
        self.assertEqual(m[3]['rows']['6'][17],{'formula':'=ROUND(Q6,1)'})

    def test_cgpa_uses_course_points(self):
        m=build_model([fixture()])
        self.assertIn('!O',m[3]['rows']['6'][8]['formula'])
        self.assertNotIn('!N',m[3]['rows']['6'][8]['formula'])

    def test_incomplete_input_does_not_get_pass_formula(self):
        r=fixture();r.issues.append('Unreadable table')
        m=build_model([r])
        self.assertEqual(m[1]['rows']['6'][14],'REVIEW REQUIRED')
        self.assertEqual(m[3]['rows']['6'][13],'REVIEW REQUIRED')
        self.assertEqual(m[2]['rows']['6'][6],'REVIEW REQUIRED')

    def test_unreadable_file_present_on_every_sheet(self):
        r=Transcript('bad.pdf',issues=['Unreadable'])
        m=build_model([r])
        for sheet in m:self.assertIn('6',sheet['rows'])

    def test_workbook_literal_text_and_pending_cache(self):
        r=fixture();r.name='=HYPERLINK("https://example.com")'
        with tempfile.TemporaryDirectory() as d:
            p=Path(d,'report.xlsx');write_xlsx([r],p)
            with zipfile.ZipFile(p) as z:
                ns={'m':NS};root=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
                name=root.find('.//m:c[@r="A6"]',ns)
                self.assertEqual(name.get('t'),'inlineStr')
                self.assertIsNone(name.find('m:f',ns))
                reg=root.find('.//m:c[@r="B6"]/m:is/m:t',ns)
                self.assertEqual(reg.text,r.registration)
                self.assertEqual(root.find('.//m:c[@r="M6"]/m:v',ns).text,'PENDING EXCEL')
                self.assertEqual(root.find('m:autoFilter',ns).get('ref'),'A5:Q6')
                self.assertEqual(root.find('.//m:pane',ns).get('topLeftCell'),'D6')

class SampleTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        p=os.environ.get('TRANSCRIPT_SAMPLES')
        if not p:raise unittest.SkipTest('Set TRANSCRIPT_SAMPLES to the sample folder or ZIP')
        cls.records=audit([p])

    def test_five_sample_totals(self):
        expected={'Aakriti Thakur':(37,122,3036,949,[1,2,3,4,5,6]),'Nayan Habib':(30,120,2777,1073,[3,4,5,6,7,8]),'Nayanika Ghosh':(11,42,171,39,[5,6]),'Parth Vekariya':(19,80,963,341,[5,6,7,8]),'Vimal Choudhary':(25,82,663,171,[3,4,5,6])}
        self.assertEqual(len(self.records),5)
        for r in self.records:
            self.assertEqual((r.course_count,r.credits,r.marks,r.weighted,r.observed_semesters),expected[r.name])
            self.assertTrue(r.complete,r.all_issues())
            self.assertEqual(r.sequence_status,'MATCH')

    def test_discrepancy_numerators(self):
        r={r.name:r for r in self.records}
        a=r['Aakriti Thakur'].semesters[4]
        self.assertEqual(a.weighted/a.credits,Fraction(84,11))
        self.assertEqual(a.printed_sgpa,'7.7')
        n=r['Nayanika Ghosh']
        self.assertEqual(n.semesters[0].weighted/n.semesters[0].credits,Fraction(39,22))
        self.assertEqual(n.weighted/n.credits,Fraction(13,14))

if __name__=='__main__':unittest.main()
