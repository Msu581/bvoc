@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo First run Setup.bat.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" -m unittest discover -s tests -v
if errorlevel 1 (
  echo.
  echo TESTS FAILED. Do not use the checker until the failure is reviewed.
  pause
  exit /b 1
)
echo.
echo All built-in tests passed.
pause
