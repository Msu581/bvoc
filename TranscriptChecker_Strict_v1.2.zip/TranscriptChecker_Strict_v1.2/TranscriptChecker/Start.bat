@echo off
setlocal
cd /d "%~dp0"
if exist "%~dp0.venv\Scripts\python.exe" (
  "%~dp0.venv\Scripts\python.exe" "%~dp0app.py"
  if errorlevel 1 pause
  exit /b
)
echo First run Setup.bat to install Python dependencies.
pause
