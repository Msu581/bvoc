# Validation and calculation rules

This project is intentionally **fail-closed**. It does not guess when extraction is uncertain. Any unreadable, unfamiliar, incomplete, duplicated, or internally inconsistent transcript is marked `REVIEW REQUIRED` instead of being silently accepted.

## Category and semester sequence

The category is read from the PDF and determines the only acceptable contiguous semester sequence:

- B.Voc Regular: 1,2,3,4,5,6
- B.Voc Lateral to Second Year: 3,4,5,6
- B.Voc Lateral to Third Year: 5,6
- B.Des Regular: 1,2,3,4,5,6,7,8
- B.Des Lateral to Second Year: 3,4,5,6,7,8
- B.Des Lateral to Third Year: 5,6,7,8

Missing, extra, repeated, or out-of-order semesters are `MISMATCH`.

## Sheet 1 - Year of passing check

For every student the report includes name, registration, category, programme, PDF passing year, expected year 2025, observed semesters, expected semesters, extraction/duplicate checks, final overall status, source path and source SHA-256.

The passing year is taken specifically from the `Year of Passing` field. Anything other than 2025 is `MISMATCH`.

## Sheet 2 - SGPA and credit check

For every semester and every subject:

- Course credit = T + P + PR.
- Semester credit = sum of course credits.
- Grade points: O=10, A+=9, A=8, B+=7, B=6, C=5, P=4, F=0, AB=0.
- Weighted points = course credit x printed grade points.
- SGPA = sum(weighted points) / sum(course credits).
- The rounded comparison is a literal Excel formula: `=ROUND(value,1)`.

The sheet contains PDF values, exact Python/rational calculations, an independent Excel calculation, exact fractions, unrounded values, rounded values, and mismatch/review flags. Subject-level evidence is retained below the semester summary.

## Sheet 3 - Max marks checking

- Unique course codes are counted **within each semester**.
- Maximum marks = total unique course count x 100.
- Obtained marks = sum of subject marks for all included semesters; AB contributes zero marks.
- Duplicate course codes in one semester are never silently deduplicated as a trusted result; they trigger review.

The sheet compares computed and PDF maximum/obtained marks and shows a semester breakdown.

## Sheet 4 - Calculations

- Total credits = sum of all subject credits.
- CGPA = sum(subject credit x grade points) / total credits.
- CGPA is **not** the average of rounded semester SGPAs.
- Percentage = obtained marks / maximum marks x 100.
- CGPA and percentage comparisons use Excel `ROUND(value,1)`.

The report carries both code-produced totals and Excel formula totals so arithmetic can be cross-checked independently.

## Extraction safety

The checker uses two independent PDF text engines (`pdfplumber` and `pypdf`) and requires agreement on numeric course rows and key printed fields. It also checks course-code coverage, semester footers, duplicate documents/registrations, source hashes, page limits, file-size limits, and the expected grading-legend image fingerprint.

A perfect 100% extraction guarantee is not technically possible for arbitrary PDFs. The design goal is instead: **never report MATCH when the program is not confident enough to justify it**. Scanned, changed-layout, encrypted, malformed, or otherwise ambiguous documents are routed to manual review.
