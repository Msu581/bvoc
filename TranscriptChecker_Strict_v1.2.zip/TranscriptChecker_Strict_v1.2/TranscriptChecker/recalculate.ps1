param([Parameter(Mandatory=$true)][string]$WorkbookPath)
$ErrorActionPreference = 'Stop'
$auditExcel = $null
$auditBook = $null
try {
    $auditExcel = New-Object -ComObject Excel.Application
    $auditExcel.Visible = $false
    $auditExcel.DisplayAlerts = $false
    $auditExcel.EnableEvents = $false
    $auditExcel.AutomationSecurity = 3
    $auditBook = $auditExcel.Workbooks.Open($WorkbookPath, 0, $false)
    $auditExcel.CalculateFullRebuild()
    if ($auditExcel.CalculationState -ne 0) { throw 'Excel calculation did not finish' }
    $auditBook.Save()
    Write-Output ('Native Excel ' + $auditExcel.Version + ': ROUND formulas recalculated and saved.')
} finally {
    if ($null -ne $auditBook) {
        $auditBook.Close($false)
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($auditBook)
    }
    if ($null -ne $auditExcel) {
        $auditExcel.Quit()
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($auditExcel)
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
