"""Strict, local MSU transcript extraction and exact arithmetic. No AI/OCR guessing."""
from __future__ import annotations
import hashlib
import io
import logging
import re
import zipfile
from collections import Counter
from dataclasses import dataclass, field, asdict
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

import pdfplumber
from pypdf import PdfReader

logging.getLogger('pdfminer').setLevel(logging.ERROR)
VERSION = '1.2.0'
MAX_FILES = 500
MAX_PDF_BYTES = 50 * 1024 * 1024
LEGEND_HASH = '993a72c96211b55e7066283273088cd334c49a99614d19d0fc65d63f7a7f40c8'
POINTS = {'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'P': 4, 'F': 0, 'AB': 0}
ORDINALS = dict(zip('FIRST SECOND THIRD FOURTH FIFTH SIXTH SEVENTH EIGHTH'.split(), range(1, 9)))
COURSE_CODE = r'[A-Z]{2,8}[0-9]{2,6}[A-Z]?'
NUM = r'\d+(?:\.\d+)?'
ROW = re.compile(rf'^({COURSE_CODE})\s+(.*?)\s*({NUM})\s*-\s*({NUM})\s*-\s*({NUM})\s+(AB|{NUM})\s+(\S+)\s*$')
TRIPLE = re.compile(rf'({NUM})\s*-\s*({NUM})\s*-\s*({NUM})\s+(AB|{NUM})\s+(\S+)')

def number(text):
    return Fraction(str(text))

def exact(value):
    value = Fraction(value)
    return str(value.numerator) if value.denominator == 1 else f'{value.numerator}/{value.denominator}'

def decimal_text(value):
    with localcontext() as ctx:
        ctx.prec = 40
        return str(Decimal(value.numerator) / Decimal(value.denominator))

def expected_grade(marks):
    m = number(marks)
    if not 0 <= m <= 100:
        raise ValueError('Marks outside 0..100')
    return next(g for lower, g in [(99,'O'), (90,'A+'), (80,'A'), (70,'B+'), (60,'B'), (50,'C'), (40,'P'), (0,'F')] if m >= lower)

def category(raw):
    s = ' '.join(raw.lower().split())
    if re.fullmatch(r'(?:regular\s*\(\s*)?lateral entry to (?:the )?third year\s*\)?', s):
        return 'Lateral to Third Year', 5
    if re.fullmatch(r'(?:regular\s*\(\s*)?lateral entry to (?:the )?second year\s*\)?', s):
        return 'Lateral to Second Year', 3
    if s == 'regular':
        return 'Regular', 1
    return 'UNKNOWN', None

def programme(raw):
    s = re.sub(r'[.\s]', '', raw.lower())
    if s in ('bachelorofvocation','bvoc'):
        return 'B.Voc', 6
    if s in ('bachelorofdesign','bdes'):
        return 'B.Des', 8
    return 'UNKNOWN', None

@dataclass
class Source:
    path: str
    member: str | None = None

    @property
    def label(self):
        return self.path + (' :: ' + self.member if self.member else '')

    def read(self):
        if self.member:
            with zipfile.ZipFile(self.path) as z:
                info = z.getinfo(self.member)
                if info.file_size > MAX_PDF_BYTES:
                    raise ValueError('PDF exceeds the 50 MB per-file limit')
                with z.open(info) as f:
                    data = f.read(MAX_PDF_BYTES + 1)
        else:
            with open(self.path, 'rb') as f:
                data = f.read(MAX_PDF_BYTES + 1)
        if len(data) > MAX_PDF_BYTES:
            raise ValueError('PDF exceeds the 50 MB per-file limit')
        return data

def discover(paths):
    """ZIP members are read in place: never extract user-controlled archive paths."""
    sources = []
    seen = set()
    def add(p):
        p = Path(p).expanduser().resolve()
        if not p.exists():
            raise ValueError(f'Path does not exist: {p}')
        if p.is_dir():
            for f in sorted(p.rglob('*')):
                if f.is_file() and f.suffix.lower() in ('.pdf', '.zip'):
                    add(f)
        elif p.suffix.lower() == '.zip':
            with zipfile.ZipFile(p) as z:
                members = [x for x in z.infolist() if not x.is_dir() and x.filename.lower().endswith('.pdf')]
                if len({x.filename for x in members}) != len(members):
                    raise ValueError(f'ZIP contains duplicate member names: {p.name}')
                for info in members:
                    put(Source(str(p), info.filename))
        elif p.suffix.lower() == '.pdf':
            put(Source(str(p)))
        else:
            raise ValueError(f'Choose a PDF, ZIP or folder: {p}')
    def put(src):
        key = (src.path.casefold(), src.member)
        if key not in seen:
            seen.add(key)
            sources.append(src)
        if len(sources) > MAX_FILES:
            raise ValueError('Maximum 500 PDFs per batch. No files were silently dropped.')
    for p in paths:
        if str(p).strip():
            add(str(p).strip().strip('"'))
    if not sources:
        raise ValueError('No PDFs found')
    return sources

@dataclass
class Course:
    code: str
    name: str
    t: str
    p: str
    pr: str
    marks: str
    grade: str
    page: int
    raw: str
    expected: str = ''
    issues: list[str] = field(default_factory=list)

    @property
    def credits(self):
        return number(self.t) + number(self.p) + number(self.pr)

    @property
    def weighted(self):
        return self.credits * POINTS.get(self.grade, 0)

    @property
    def obtained(self):
        return Fraction(0) if self.marks == 'AB' else number(self.marks)

@dataclass
class Semester:
    number: int
    page: int
    y: float
    side: int
    printed_credits: str | None = None
    printed_sgpa: str | None = None
    courses: list[Course] = field(default_factory=list)
    issues: list[str] = field(default_factory=list)

    @property
    def credits(self):
        return sum((c.credits for c in self.courses), Fraction())

    @property
    def weighted(self):
        return sum((c.weighted for c in self.courses), Fraction())

    @property
    def marks(self):
        return sum((c.obtained for c in self.courses), Fraction())

@dataclass
class Transcript:
    source: str
    sha256: str = ''
    name: str = ''
    registration: str = ''
    category_raw: str = ''
    category: str = 'UNKNOWN'
    programme: str = 'UNKNOWN'
    passing_year: str | None = None
    expected_semesters: list[int] = field(default_factory=list)
    semesters: list[Semester] = field(default_factory=list)
    printed: dict = field(default_factory=dict)
    issues: list[str] = field(default_factory=list)
    duplicate_issues: list[str] = field(default_factory=list)
    legend_page: int | None = None
    legend_any_image_seen: bool = False

    @property
    def observed_semesters(self):
        return [s.number for s in self.semesters]

    @property
    def sequence_status(self):
        if not self.expected_semesters or not self.semesters:
            return 'REVIEW REQUIRED'
        return 'MATCH' if self.observed_semesters == self.expected_semesters else 'MISMATCH'

    @property
    def complete(self):
        return not self.issues and bool(self.semesters) and not any(s.issues for s in self.semesters)

    @property
    def credits(self):
        return sum((s.credits for s in self.semesters), Fraction())

    @property
    def weighted(self):
        return sum((s.weighted for s in self.semesters), Fraction())

    @property
    def marks(self):
        return sum((s.marks for s in self.semesters), Fraction())

    @property
    def course_count(self):
        return sum(len(set(c.code for c in s.courses)) for s in self.semesters)

    def all_issues(self):
        return self.issues + self.duplicate_issues + [f'Sem {s.number}: {e}' for s in self.semesters for e in s.issues] + [f'Sem {s.number} {c.code}: {e}' for s in self.semesters for c in s.courses for e in c.issues]

def only(pattern, text, label, issues):
    found = re.findall(pattern, text, re.I | re.M)
    if len(found) != 1:
        issues.append(f'{label}: expected one value, found {len(found)}')
        return None
    return found[0].strip()

def parse_pdf(src):
    result = Transcript(src.label)
    try:
        data = src.read()
        result.sha256 = hashlib.sha256(data).hexdigest()
        if not data.startswith(b'%PDF-'):
            raise ValueError('File is not a PDF')
        with pdfplumber.open(io.BytesIO(data)) as pdf:
            if not 1 <= len(pdf.pages) <= 20:
                raise ValueError('Expected 1..20 transcript pages; unsupported document')
            texts = [page.extract_text(x_tolerance=2, y_tolerance=3) or '' for page in pdf.pages]
            whole = '\n'.join(texts)
            if 'ACADEMIC TRANSCRIPT' not in whole:
                raise ValueError('No readable academic transcript. Scanned or unsupported PDF needs review; OCR is not auto-approved.')
            result.name = only(r'Name of the Student\s*:\s*(.*?)\s+Registration', whole, 'Student name', result.issues) or ''
            result.registration = only(r'Registration\s+No\.?\s*:\s*(\S+)', whole, 'Registration', result.issues) or ''
            result.category_raw = only(r'Category\s*:\s*(.*?)\s+Programme\s*:', whole, 'Category', result.issues) or ''
            prog = only(r'Programme\s*:\s*([^\n]+)', whole, 'Programme', result.issues) or ''
            result.category, start = category(result.category_raw)
            result.programme, end = programme(prog)
            if start is None or end is None:
                result.issues.append('Unknown programme/category; semester range cannot be inferred safely')
            else:
                result.expected_semesters = list(range(start, end + 1))
            result.passing_year = only(r'Year of Passing\s*:\s*(\d{4})\b', whole, 'Year of passing', result.issues)
            for key, label in [('max_marks',r'MAX\.?\s*MARKS'),('obtained',r'OBTAINED\s+MARKS'),('percentage',r'PERCENTAGE'),('credits',r'TOTAL\s+CREDITS'),('cgpa',r'CGPA')]:
                result.printed[key] = only(rf'{label}\s*:\s*({NUM})\b', whole, key, result.issues)
            for pg, page in enumerate(pdf.pages, 1):
                for im in page.images:
                    result.legend_any_image_seen = True
                    if hashlib.sha256(im['stream'].get_rawdata()).hexdigest() == LEGEND_HASH:
                        result.legend_page = pg
                if abs(page.width / page.height - 1.414) > .04:
                    result.issues.append(f'Page {pg}: unsupported page aspect ratio')
                for side in (0,1):
                    box = (page.width * side / 2, 0, page.width * (side + 1) / 2, page.height)
                    half = page.crop(box)
                    words = half.extract_words(x_tolerance=2, y_tolerance=3)
                    headings = []
                    for i,w in enumerate(words[:-1]):
                        if w['text'] in ORDINALS and words[i+1]['text'] == 'SEMESTER' and abs(w['top']-words[i+1]['top']) < 3:
                            headings.append((ORDINALS[w['text']], w['top'], w['bottom']))
                    for i,(n,y,bottom) in enumerate(headings):
                        stop = headings[i+1][1] if i+1 < len(headings) else page.height
                        block = half.crop((box[0], bottom, box[2], stop)).extract_text(x_tolerance=2,y_tolerance=3) or ''
                        sem = parse_block(n, pg, y, side, block)
                        result.semesters.append(sem)
            result.semesters.sort(key=lambda s: (s.page, round(s.y/5), s.side))
            if not result.legend_page:
                if result.legend_any_image_seen:
                    result.issues.append('Grading legend image is present but its fingerprint does not match the visually verified sample legend (different or altered legend)')
                else:
                    result.issues.append('Grading legend image is missing from the document (no legend image found at all)')
            if not result.semesters:
                result.issues.append('No semester tables extracted')
            # Independent text engine cross-check: numeric row token multiset on every page.
            reader = PdfReader(io.BytesIO(data))
            independent_texts = []
            for pg,page in enumerate(reader.pages,1):
                raw = page.extract_text() or ''
                independent_texts.append(raw)
                independent = Counter(tuple(m) for m in TRIPLE.findall(raw))
                parsed = Counter((c.t,c.p,c.pr,c.marks,c.grade) for s in result.semesters if s.page==pg for c in s.courses)
                if independent != parsed:
                    result.issues.append(f'Page {pg}: independent extraction disagrees on numeric course rows')
                # Both engines must also agree on every printed numeric summary and identity.
                if pg == 1:
                    compact = re.sub(r'\s+', '', raw)
                    if result.registration not in compact or re.sub(r'\s+','',result.name) not in compact:
                        result.issues.append('Independent extraction disagrees on student identity')
            compact = re.sub(r'\s+', '', '\n'.join(independent_texts))
            for label,value in [('Category',result.category_raw),('Programme',prog),('YearofPassing',result.passing_year)]:
                if value and label+':'+re.sub(r'\s+','',value) not in compact:
                    result.issues.append('Independent extraction disagrees on '+label)
            for key,label in [('max_marks',r'MAX\.?MARKS'),('obtained','OBTAINEDMARKS'),('percentage','PERCENTAGE'),('credits','TOTALCREDITS'),('cgpa','CGPA')]:
                values = re.findall(label+rf':({NUM})',compact)
                if values != [result.printed.get(key)]:
                    result.issues.append('Independent extraction disagrees on '+key)
            independent_footers = Counter(re.findall(rf'CREDITS?:({NUM})SGPA:({NUM})',compact))
            if independent_footers != Counter((s.printed_credits,s.printed_sgpa) for s in result.semesters):
                result.issues.append('Independent extraction disagrees on semester CREDIT/SGPA footers')
            # Require exact coverage of all course-like codes, not just rows matched by our regex.
            all_codes = Counter(re.findall(rf'\b({COURSE_CODE})\b', whole))
            parsed_codes = Counter(c.code for s in result.semesters for c in s.courses)
            if all_codes != parsed_codes:
                result.issues.append('Course-code coverage mismatch: an unparsed, repeated or extra course code exists')
    except Exception as exc:
        result.issues.append(f'{type(exc).__name__}: {exc}')
    return result

def parse_block(n,pg,y,side,block):
    sem = Semester(n, pg, y, side)
    footer = list(re.finditer(rf'CREDITS?\s*:\s*({NUM})\s+SGPA\s*:\s*({NUM})', block))
    if len(footer) != 1:
        sem.issues.append(f'Expected one CREDIT/SGPA footer; found {len(footer)}')
    if footer:
        sem.printed_credits, sem.printed_sgpa = footer[0].groups()
        table = block[:footer[0].start()]
    else:
        table = block
    for line in table.splitlines():
        match = ROW.fullmatch(line.strip())
        if not match:
            if re.match(rf'^{COURSE_CODE}\b', line) or TRIPLE.search(line):
                sem.issues.append('Unparsed course row: '+line)
            continue
        code,name,t,p,pr,marks,grade = match.groups()
        course = Course(code, name or '(wrapped title; see PDF)',t,p,pr,marks,grade,pg,line)
        if course.credits <= 0:
            sem.issues.append(f'{code}: zero or invalid total course credits')
        if grade not in POINTS:
            sem.issues.append(f'{code}: unknown grade {grade}')
        try:
            if marks == 'AB':
                course.expected = 'AB'
            elif grade == 'AB' and number(marks) == 0:
                course.expected = 'AB'
            else:
                course.expected = expected_grade(marks)
            if grade != course.expected:
                course.issues.append(f'Marks/grade mismatch: expected {course.expected}, printed {grade}')
        except ValueError as exc:
            sem.issues.append(f'{code}: {exc}')
        sem.courses.append(course)
    counts = Counter(c.code for c in sem.courses)
    if any(v>1 for v in counts.values()):
        sem.issues.append('Duplicate course code within semester: '+', '.join(k for k,v in counts.items() if v>1))
    if not sem.courses:
        sem.issues.append('No course rows')
    if sem.printed_sgpa is not None and not 0 <= number(sem.printed_sgpa) <= 10:
        sem.issues.append('Printed SGPA is outside 0..10')
    return sem

def mark_duplicates(records):
    for r in records:
        r.duplicate_issues.clear()
    for attr,label in [('sha256','Duplicate PDF content'),('registration','Duplicate registration in batch')]:
        counts = Counter(getattr(r,attr) for r in records if getattr(r,attr))
        for r in records:
            if getattr(r,attr) and counts[getattr(r,attr)] > 1:
                r.duplicate_issues.append(label)

def audit(paths, progress=None):
    sources = discover(paths)
    records = []
    for i,src in enumerate(sources,1):
        records.append(parse_pdf(src))
        if progress:
            progress(i,len(sources),records[-1])
    mark_duplicates(records)
    return records

def to_dict(records):
    return [asdict(r) for r in records]
